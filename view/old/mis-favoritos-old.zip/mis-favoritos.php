<?php

if (! $_SESSION['usuario']) {
    header('location: ?view=403');
    //header('location: ./?view=home');
    die();
}

$favoritos = [];
$rom_qty = 0;
$nº = 1;

$favoritos = get_json('json/favoritos.json');

$productos = get_json('json/productos.json');

// Guarda datos del usuario actual
$userId = $_SESSION['usuario']['id'];
$qty_fav = $_SESSION['usuario'][0]['qty_fav'];

// Verifica primero en toda la base de datos del favoritos si el usuario ya agrego algo anteriormente
$posUser = null; // Inicializa variable Posicion Usuario como NULA

foreach ($favoritos as $index => $value) {
    if ($value['user_id'] == $userId) {
        $posUser = $index; // Guarda posicion del usuario
    }
}

if ($_POST) {

    if (isset($_POST['ver'])) {
        header('location: ?view=articulo&cat='.$_POST['cat'].'&id='.$_POST['ver']);
        die;
    }

    if (isset($_POST['mas'])) {
        header('location: ?view=detalle&cat='.$_POST['cat']);
        die;
    }


    if (isset($_POST['eliminar'])) {

        // Busca la posicion del Articulo sobre el cual operar
        $posArt = pos_art('json/favoritos.json', $posUser, $_POST['eliminar']);

        // Borra TODA la clave del producto
        unset($favoritos[$posUser]['productos'][$posArt]);

        // Sobrescribe la cantidad en SESSION
        $qty_fav = $qty_fav - 1;
        $_SESSION['usuario'][0]['qty_fav'] = $qty_fav;

    }

    // Graba la nueva base
    save_json($favoritos,'./json/favoritos.json');

    // Recarga la pagina y evita reenvio de formulario
    header('location: ?view=mis-favoritos');

}

?>

<div class="container" id="mis-favoritos">

    <?php require 'require/header.php'; ?>

    <div class="row">
        <div class="col">
            <h4>Mis Favoritos <i class="fa fa-heart" aria-hidden="true"></i></h4>
            <h6>Usuario ID (<?= $userId ?>) | Cantidad Items (<?= $posUser ? count($favoritos[$posUser]['productos']) : 0 ?>)</h6>

            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Nº</th>
                        <th>Img</th>
                        <th>ID</th>
                        <th>Titulo</th>
                        <th>Categoria</th>
                        <th>Estado</th>
                        <th>Precio</th>
                        <th>Stk</th>
                        <th>Cantidad</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if ( $posUser !== null ) : ?>
                        <?php foreach ($favoritos[$posUser]['productos'] as $key => $articulo): ?>
                            <?php foreach ($productos as $id => $producto): ?> 
                                <?php if ($articulo['prod_id'] == $producto['id']): ?>     
                                    <tr>
                                        <td><?= $nº++ ?></td>
                                        <td>
                                            <img src="<?= $producto['imagen'] ?>" style="width: 30px;">
                                        </td>
                                        <td><?= $producto['id'] ?></td>
                                        <td><?= $producto['titulo'] ?></td>
                                        <td><?= cat_name($producto['cat_id']) ?></td>
                                        <td><?= $producto['estado'] ?></td>
                                        <td><?= $producto['moneda'].' '.$producto['precio'] ?></td>
                                        <td><?= $producto['stock'] ?></td>
                                        <form action="" method="post">
                                            <input type="hidden" name="stock_qty" value="<?= $producto['stock'] ?>">
                                            <input type="hidden" name="cat" value="<?= cat_name($producto['cat_id']) ?>">
                                            <!--<td class="arrow-input">
                                                <input type="text" id="prod-qty" class="form-control" name="input_qty" value="<?= $articulo['prod_qty'] ?>" autocomplete="off">
                                                <div id="arrows">
                                                    <button class="" name="arrow-up" value="<?= $producto['id'] ?>">▲</button>
                                                    <button class="" name="arrow-down" value="<?= $producto['id'] ?>">▼</button>
                                                </div>
                                            </td>-->
                                            <td>
                                                <button class="btn btn-sm btn-primary" title="Ver" name="ver" value="<?= $producto['id'] ?>"> <i class="fas fa-eye"></i> </button>
                                                <button class="btn btn-sm btn-warning" title="Mas Similares" name="mas" value="<?= $producto['id'] ?>"> <i class="fas fa-cart-plus" style="color: white;"></i> </button>
                                                <button class="btn btn-sm btn-success" title="Guardar" name="guardar" value="<?= $producto['id'] ?>"> <i class="far fa-save" style="color: white;"></i> </button>
                                                <button class="btn btn-sm btn-danger" title="Eliminar" name="eliminar" value="<?= $producto['id'] ?>"> <i class="fas fa-cart-arrow-down"></i> </button>
                                            </td>
                                        </form>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php require 'require/footer.php'; ?>

</div>