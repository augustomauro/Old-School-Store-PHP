<?php

if (! $_SESSION['usuario']) {
    header('location: ?view=403');
    //header('location: ./?view=home');
    die();
}

$carrito = [];
$rom_qty = 0;
$nº = 1;

$carrito = get_json('json/carrito.json');

$productos = get_json('json/productos.json');

// Guarda datos del usuario actual
$userId = $_SESSION['usuario']['id'];
$qty_cart = $_SESSION['usuario'][0]['qty_cart'];

// Verifica primero en toda la base de datos del carrito si el usuario ya agrego algo anteriormente
$posUser = null; // Inicializa variable Posicion Usuario como NULA

foreach ($carrito as $index => $value) {
    if ($value['user_id'] == $userId) {
        $posUser = $index; // Guarda posicion del usuario
    }
}

if ($_POST) {

    if (isset($_POST['ver'])) {
        header('location: ?view=articulo&cat='.$_POST['cat'].'&id='.$_POST['ver']);
        die;
    }

    if (isset($_POST['mas'])) {
        header('location: ?view=detalle&cat='.$_POST['cat']);
        die;
    }

    if (isset($_POST['arrow-up'])) {

        // Busca la posicion del Articulo sobre el cual operar
        $posArt = pos_art('json/carrito.json', $posUser, $_POST['arrow-up']);

        if ( (int)$_POST['input_qty'] < (int)$_POST['stock_qty'] ) {
            // Si es menor al maximo de stock, Suma de a uno
            $carrito[$posUser]['productos'][$posArt]['prod_qty']++;
            $qty_cart++;
            $_SESSION['usuario'][0]['qty_cart'] = $qty_cart;
        }
        
    }

    if (isset($_POST['arrow-down'])) {

        // Busca la posicion del Articulo sobre el cual operar
        $posArt = pos_art('json/carrito.json', $posUser, $_POST['arrow-down']);

        if ( (int)$_POST['input_qty'] > 1 ) {
            // Si es mayor a 1, Resta de a uno
            $carrito[$posUser]['productos'][$posArt]['prod_qty']--;
            $qty_cart--;
            $_SESSION['usuario'][0]['qty_cart'] = $qty_cart;
        }
        
    }

    if (isset($_POST['eliminar'])) {

        // Busca la posicion del Articulo sobre el cual operar
        $posArt = pos_art('json/carrito.json', $posUser, $_POST['eliminar']);

        // Borra TODA la clave del producto
        unset($carrito[$posUser]['productos'][$posArt]);

        // Guarda la cantidad que habia originalmente en el carrito
        if (isset($_POST['input_qty'])) {
            $rom_qty = $_POST['input_qty'];
        }

        // Sobrescribe la cantidad en SESSION
        $qty_cart = $qty_cart - $rom_qty;
        $_SESSION['usuario'][0]['qty_cart'] = $qty_cart;

    }

    // Graba la nueva base
    save_json($carrito,'./json/carrito.json');

    // Recarga la pagina y evita reenvio de formulario
    header('location: ?view=mi-carrito');

}

?>

<div class="container" id="mi-carrito">

    <?php require 'require/header.php'; ?>

    <div class="row">
        <div class="col">
            <h4>Mi Carrito <i class="fa fa-shopping-cart" aria-hidden="true"></i></h4>
            <h6>Usuario ID (<?= $userId ?>) | Cantidad Items (<?= $posUser ? count($carrito[$posUser]['productos']) : 0 ?>)</h6>

            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Nº</th>
                        <th>Img</th>
                        <th>ID</th>
                        <th>Titulo</th>
                        <th>Categoria</th>
                        <th>Estado</th>
                        <th>Subtot</th>
                        <th>Stk</th>
                        <th>Cantidad</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if ( $posUser !== null ) : ?>
                        <?php foreach ($carrito[$posUser]['productos'] as $key => $articulo): ?>
                            <?php foreach ($productos as $id => $producto): ?> 
                                <?php if ($articulo['prod_id'] == $producto['id']): ?>     
                                    <tr>
                                        <td><?= $nº++ ?></td>
                                        <td>
                                            <img src="<?= $producto['imagen'] ?>" style="width: 30px;">
                                        </td>
                                        <td><?= $producto['id'] ?></td>
                                        <td><?= $producto['titulo'] ?></td>
                                        <td><?= cat_name($producto['cat_id']) ?></td>
                                        <td><?= $producto['estado'] ?></td>
                                        <td><?= $producto['moneda'].' '.$producto['precio']*$articulo['prod_qty'] ?></td>
                                        <td><?= $producto['stock'] ?></td>
                                        <form action="" method="post">
                                            <input type="hidden" name="stock_qty" value="<?= $producto['stock'] ?>">
                                            <input type="hidden" name="cat" value="<?= cat_name($producto['cat_id']) ?>">
                                            <td class="arrow-input">
                                                <input type="text" id="prod-qty" class="form-control" name="input_qty" value="<?= $articulo['prod_qty'] ?>" autocomplete="off">
                                                <div id="arrows">
                                                    <button class="" name="arrow-up" value="<?= $producto['id'] ?>">▲</button>
                                                    <button class="" name="arrow-down" value="<?= $producto['id'] ?>">▼</button>
                                                </div>
                                            </td>
                                            <td>
                                                <button class="btn btn-sm btn-primary" title="Ver" name="ver" value="<?= $producto['id'] ?>"> <i class="fas fa-eye"></i> </button>
                                                <button class="btn btn-sm btn-warning" title="Mas Similares" name="mas" value="<?= $producto['id'] ?>"> <i class="fas fa-cart-plus" style="color: white;"></i> </button>
                                                <button class="btn btn-sm btn-success" title="Guardar" name="guardar" value="<?= $producto['id'] ?>"> <i class="far fa-save" style="color: white;"></i> </button>
                                                <button class="btn btn-sm btn-danger" title="Eliminar" name="eliminar" value="<?= $producto['id'] ?>"> <i class="fas fa-cart-arrow-down"></i> </button>
                                            </td>
                                        </form>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php require 'require/footer.php'; ?>

</div>