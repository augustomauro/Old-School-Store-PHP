<?php

$usuarios = get_json('json/users.json');

if ($_POST) {
    // Usuario a borrar:
    $us_delete = $_POST['eliminar'];

    // Verifica posicion original del usuario dentro de users.json
    $i = 0;
    foreach ($usuarios as $usuario) {
        if ( $usuario['id'] === $us_delete ) {
        $pos = $i;
        }
        $i++;
    }

    // Elimina la imagen asociada (avatar) si existe
    if ($usuarios[$pos]['avatar'] != null) {
        unlink($usuarios[$pos]['avatar']);
    }

    $resultado = [];
    $us1 = [];
    $us2 = [];
    $res1 = [];
    $res2 = [];
    if ($pos == 0) {
        // El usuario esta en posicion inicial. Selecciona desde 1 hasta el ultimo
        $resultado = array_splice($usuarios, 1, (count($usuarios)-1));
    } elseif ($pos == (count($usuarios)-1)) {
        // El usuario esta en posicion final. Selecciona desde 0 hasta anteultimo
        $resultado = array_splice($usuarios, 0, -1);
    } else {
        // El usuario esta en el medio.
        $us1 = $usuarios;
        $us2 = $usuarios;
        // Corta y guarda desde $pos+1 hasta el ultimo
        $res1 = array_splice($us1, $pos+1, (count($usuarios)-1));
        // Corta y guarda desde 0 hasta $pos
        $res2 = array_splice($us2, 0, $pos);
        // Hace merge del array final resultante
        $resultado = array_merge($res2, $res1);
    }

    // Grabamos la nueva base a json (reemplaza la anterior)
    save_json($resultado,'./json/users.json');
    // Recarga la pagina
    header('location: ?admin=users-list');

    //var_dump($resultado);
}

?>

<div class="container">
    <div class="row">
        <div class="col">
            <h1>Usuarios Registrados (<?= count($usuarios) ?>)</h1>

            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Nº</th>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Apellido</th>
                        <th>Email Principal</th>
                        <th>Avatar</th>
                    </tr>
                </thead>

                <tbody>
                    <?php foreach ($usuarios as $id => $usuario): ?>
                        <tr>
                            <td><?= $id ?></td>
                            <td><?= $usuario['id'] ?></td>
                            <td><?= $usuario['firstname'] ?></td>
                            <td><?= $usuario['lastname'] ?></td>
                            <td><?= $usuario['email1'] ?></td>
                            <td>
                                <img src="<?= $usuario['avatar'] ?>" style="border-radius: 50%; width: 25px;">
                            </td>
                            <td>
                                <form action="" method="post">
                                    <button class="btn btn-sm btn-success" name="detalle" value="<?= $usuario['id'] ?>">Detalles</button>
                                    <button class="btn btn-sm btn-primary" name="editar" value="<?= $usuario['id'] ?>">Editar</button>
                                    <button class="btn btn-sm btn-danger" name="eliminar" value="<?= $usuario['id'] ?>">Borrar</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach ?>
                </tbody>
            </table>
        </div>
    </div>
</div>